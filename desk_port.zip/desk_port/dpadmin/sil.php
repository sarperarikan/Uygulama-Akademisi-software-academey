﻿<?php
require_once("baglan.php");
TRY
{
 $_POST['sil'];
$sorgu = $db->query("DELETE  FROM mesaj");

$sorgu->execute();
echo "<script>window.location.href='admin.php';</script>";

}
catch(PDOException $e)
{
echo $e->getMessage();
}
 
?>