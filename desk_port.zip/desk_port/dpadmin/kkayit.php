<?php
	require 'config.php';

	if(isset($_POST['register'])) {
		$errMsg = '';

		// Get data from FROM
		$fullname = $_POST['fullname'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		$secretpin = $_POST['secretpin'];

		if($fullname == '')
			$errMsg = 'Tam adınızı giriniz';
		if($username == '')
			$errMsg = 'Kullanıcı adını girin';
		if($password == '')
			$errMsg = 'Şifrenizi girin';
		if($secretpin == '')
			$errMsg = 'Gizli pin numarasını giriniz';

		if($errMsg == ''){
			try {
				$stmt = $connect->prepare('INSERT INTO pdo (fullname, username, password, secretpin) VALUES (:fullname, :username, :password, :secretpin)');
				$stmt->execute(array(
					':fullname' => $fullname,
					':username' => $username,
					':password' => $password,
					':secretpin' => $secretpin
					));
				header('Location: register.php?action=joined');
				exit;
			}
			catch(PDOException $e) {
				echo $e->getMessage();
			}
		}
	}

	if(isset($_GET['action']) && $_GET['action'] == 'joined') {
		$errMsg = '<h4>Kaydınız başarıyla tamamlandı. Şimdi  <a href="login.php" accesskey="g">giriş</a> linkinden portala ulaşabilirsiniz.</h4>';
	}
?>

<html>
<head><title>Kayıt Ol-Deskport Destek Portalı</title></head>
	<style>
	html, body {
		margin: 1px;
		border: 0;
	}
	</style>
<style type="text/css">

div.topbar{
height: 16px;
background: #e16031;
}

ul.claybricks{
font-weight: bold;
width: 100%;
background: #e3e490;
padding: 6px 0 6px 0;
margin: 0;
text-align: left;
}

ul.claybricks li{
display: inline;
}

ul.claybricks li a{
color:mediumaquamarine;
padding: 6px 8px 4px 8px;
margin-right: 20px;
text-decoration: none;
}

ul.claybricks li a:hover, ul.claybricks li a.selected{
color: white;
background: #5d4137;
background: -moz-linear-gradient(top, #5d4137 0%, #41251b 12%, #2c0f05 100%);
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#5d4137), color-stop(12%,#41251b), color-stop(100%,#2c0f05));
background: -webkit-linear-gradient(top, #5d4137 0%,#41251b 12%,#2c0f05 100%);
background: -o-linear-gradient(top, #5d4137 0%,#41251b 12%,#2c0f05 100%);
background: -ms-linear-gradient(top, #5d4137 0%,#41251b 12%,#2c0f05 100%);
background: linear-gradient(top, #5d4137 0%,#41251b 12%,#2c0f05 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#5d4137', endColorstr='#2c0f05',GradientType=0 );
-moz-box-shadow: 0 0 5px #595959;
-webkit-box-shadow: 0 0 5px #595959;
box-shadow: 0 0 5px #595959;
padding-top: 17px;
padding-bottom: 6px;
}

</style>


<body>


	<div align="center">
		<div style=" border: solid 1px #006D9C; " align="left">
			<?php
				if(isset($errMsg)){
					echo '<div style="color:#FF0000;text-align:center;font-size:17px;">'.$errMsg.'</div>';
				}
			?>
			<div style="background-color:#006D9C; color:#FFFFFF; padding:10px;"><b>Register</b></div>
			<div style="margin: 15px">
				<form action="" method="post">
					
                    <h4>Tam Ad ve Soyadınız :</h4>
                    <input type="text" name="fullname" placeholder="Tam adınızı ve soyadınızı belirtin" value="<?php if(isset($_POST['fullname'])) echo $_POST['fullname'] ?>" autocomplete="off" class="box"/><br /><br />
					
                    <h4>Kullanıcı Adınız :</h4>
                    <input type="text" name="username" placeholder="Kullanıcı adı belirtiniz." value="<?php if(isset($_POST['username'])) echo $_POST['username'] ?>" autocomplete="off" class="box"/><br /><br />
					
                    <h4>Şifrenizi Girin :</h4></h4>
                    <input type="password" name="password" placeholder="Şifrenizi belirleyin" value="<?php if(isset($_POST['password'])) echo $_POST['password'] ?>" class="box" /><br/><br />
					
                    <h4>Hatırlatma Şifresi :</h4>
                    <input type="number" name="secretpin" placeholder="Şifrenizi unutmanız halinde kullanacağınız pin numarasını belirleyin" value="<?php if(isset($_POST['secretpin'])) echo $_POST['secretpin'] ?>" autocomplete="off" class="box"/><br /><br />
					<input type="submit" name='register' value="Kayıt Ol" accesskey="k"  class='submit'/><br />
				</form>
			</div>
		</div>
	</div>
</body>
</html>
