﻿<?php
require_once("config.php");
$veri1 = $connect->query("SELECT * FROM pdo");
$say1 = $veri1->rowCount();echo "<h4><strong>Portal İstatistikleri</strong></h4>";
echo "Portaldaki  kayıtlı toplam kullanıcı sayısı :" . " " . $say1 . "<br>";

$veri2 = $connect->query("SELECT * FROM mesaj");
$say2 = $veri2->rowCount();
echo "Portaldaki toplam mesaj sayısı :" . " " . $say2;
    
   
   
   ?>