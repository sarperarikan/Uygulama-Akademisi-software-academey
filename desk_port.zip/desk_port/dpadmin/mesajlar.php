﻿<?php
        require_once("baglan.php");
        try{
            $listele = $db->query("SELECT * FROM MESAJ");
            $say = $listele->rowCount();
            if($say)
            {
                foreach($listele  as $cek)
                {
                    print $cek['msjbaslik'] . " ". $cek['msjicerik'] . "<br>";
                }
            }

        }
        catch(PDOException $h)
        {
            echo $h->getMessage();
        }

        ?>
