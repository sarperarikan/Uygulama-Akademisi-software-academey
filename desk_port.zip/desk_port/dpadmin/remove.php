<?php
	require 'config.php';

	if(isset($_POST['removeuser'])) {
		$errMsg = '';
		// Get username from FORM
		$usernameid = $_POST['usernameid'];

		if($usernameid == '')
			$errMsg = '';

		if($errMsg == '') {
			try{
				$stmt = $connect->prepare('DELETE FROM admin WHERE id = :id OR username = :username LIMIT 1');
				$stmt->execute(array(
					':id' => $usernameid,
					':username' => $usernameid
					));

				$errMsg = '<h4>Kullanıcı ' . $usernameid . ' başarıyla silindi.</h4>';

			}
			catch(PDOException $e) {
				$errMsg = $e->getMessage();
			}
		}
	}
?>

<html>
<head><title>Remove User</title></head>
	<style>
	html, body {
		margin: 1px;
		border: 0;
	}
	</style>
<body>
	<div align="center">
		<div style=" border: solid 1px #006D9C; " align="left">
			<?php
				if(isset($errMsg)){
					echo '<div style="color:#FF0000;text-align:center;font-size:17px;">'.$errMsg.'</div>';
				}
			?>
			<div style="background-color:#006D9C; color:#FFFFFF; padding:10px;"><b>Remove User</b></div>
			<div style="margin: 15px">
				<form action="" method="post">
				Kullanıcı adınızı vveya idinizi girin <br>
					<input type="text" name="usernameid" placeholder="Kullanıcı kimliğinizi girin" autocomplete="off" class="box"/><br /><br />
					<input type="submit" name='removeuser' value="Kaldır" accesskey="k" class='submit'/><br />
				</form>
			</div>
		</div>
	</div>
</body>
</html>
