﻿<!DOCTYPE html>
<html lang='en'>
<head>
	<meta charset='UTF-8'>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<link href="stil.css" type="text/css" rel="stylesheet"/>
<body>
<?php
echo "<h5><strong>Bu proje hakları: </strong></h5>";   
echo "<h5><strong><a href='https://www.sarperarikan.com'>Sarper Arıkan</a> aittir.</strong></h5>";

?>
</body>
</html>