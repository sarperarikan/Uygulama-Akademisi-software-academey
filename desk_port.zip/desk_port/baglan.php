<?php
try
{
    $db = new PDO("mysql:host=localhost;dbname=mesajlasma;charset=utf8", 'root', 'Sarper2533!');
    

        
}
catch(PDOException $e)
{
    echo $e->getMessage();
}

?>