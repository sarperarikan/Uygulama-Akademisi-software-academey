<html>
<head><title>Deskport Destek Portalı </title></head>
	<style>
	html, body {
		margin: 1px;
		border: 0;
	}
	</style>
<body>
	<div align="center">
		<div style=" border: solid 1px #079B96; " align="left">
			<?php
				if(isset($errMsg)){
					echo '<div style="color:#FF0000;text-align:center;font-size:18px;">'.$errMsg.'</div>';
				}
			?>
			<div style="background-color:#006D9C; color:#FFFFFF; padding:10px;"><b><h4>DESKPORT-DESTEK PORTALI YAZILIMINA HOŞGELDİNİZ!</h4></b></div>
			<div style="margin: 15px">
				Sayın Misafir Hoşgeldiniz !
				<br>
				<a href="login.php" accesskey="g">Giriş</a> <br>
				<a href="register.php" accesskey="k">Kayıt Ol</a> <br>
				<a href="forgot.php" accesskey="ş">Şifre Hatırlatma</a>
			</div>
		</div>
	</div>
</body>
</html>
