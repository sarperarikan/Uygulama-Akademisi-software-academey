<?php
	require 'config.php';
	if(empty($_SESSION['name']))
		header('Location: login.php');
?>

<html>
<head>
    <title>DESKPORT Destek Yazılımı </title>
    <script src="http://code.jquery.com/jquery-1.9.1.min.js" type="text/javascript"></script>

    <script>
        $(document).ready(function () {

            $(".mesaj_panosu").load("veriler.php");

        });

        setInterval(function () { $("#divimiz").load('veriler.php'); }, 1000);
    </script>




    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />

    <style>
        html, body {
            margin: 1px;
            border: 0;
        }

        div.topbar {
            height: 16px;
            background: #e16031;
        }

        ul.claybricks {
            font-weight: bold;
            width: 100%;
            background: #e3e490;
            padding: 6px 0 6px 0;
            margin: 0;
            text-align: left;
        }

            ul.claybricks li {
                display: inline;
            }

                ul.claybricks li a {
                    color: mediumaquamarine;
                    padding: 6px 8px 4px 8px;
                    margin-right: 20px;
                    text-decoration: none;
                }

                    ul.claybricks li a:hover, ul.claybricks li a.selected {
                        color: white;
                        background: #5d4137;
                        background: -moz-linear-gradient(top, #5d4137 0%, #41251b 12%, #2c0f05 100%);
                        background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#5d4137), color-stop(12%,#41251b), color-stop(100%,#2c0f05));
                        background: -webkit-linear-gradient(top, #5d4137 0%,#41251b 12%,#2c0f05 100%);
                        background: -o-linear-gradient(top, #5d4137 0%,#41251b 12%,#2c0f05 100%);
                        background: -ms-linear-gradient(top, #5d4137 0%,#41251b 12%,#2c0f05 100%);
                        background: linear-gradient(top, #5d4137 0%,#41251b 12%,#2c0f05 100%);
                        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#5d4137', endColorstr='#2c0f05',GradientType=0 );
                        -moz-box-shadow: 0 0 5px #595959;
                        -webkit-box-shadow: 0 0 5px #595959;
                        box-shadow: 0 0 5px #595959;
                        padding-top: 17px;
                        padding-bottom: 6px;
                    }
    </style>
</head>

<body>
    <div class="topbar"></div>
    <ul class="claybricks">
        <li>
            <a href="destek.php" accesskey="1">Ana sayfa</a>
        </li>
        <li>
            <a href="mailto:sarperarikan@akdeniz.edu.tr" accesskey="2">Teknik Destek Başvurusu</a>
        </li>

    </ul>



	<div align="center">
		<div style=" border: solid 1px #006D9C; " align="left">
			<?php
				if(isset($errMsg)){
					echo '<div style="color:#FF0000;text-align:center;font-size:17px;">'.$errMsg.'</div>';
				}
			?>
			<div style="background-color:#006D9C; color:#FFFFFF; padding:10px;"><b><?php echo $_SESSION['name']; ?></b></div>
			<div style="margin: 15px">
				Hoşgeldiniz <?php echo $_SESSION['name']; ?> <br>
				<a href="update.php" accesskey="g">Hesabı Güncelle</a> <br>
				<a href="logout.php" accesskey="ç">Çıkış</a>
			</div>
		</div>
	</div>



    
  <h4>Mesaj Panosu:</h4>
    <br>
	<br>
	<br>
	
	
	<div class="mesaj_panosu">    


        
        

        
            
  <hr />
    <br />
    <br />
    <br />
    <br />
    
    <hr />
	</div>
            <h4>İleti Alanı:</h4>
    
        <form action="" method="post">
            <input type="text" name="mesaj" placeholder="Mesajınızı yazın" tabindex="1" />
            <input type="submit" name="gonder" value="Gönder" accesskey="g" tabindex="2" />
        </form>
  <?php include "foother.php";?>  
</body>
</html>

<?php
require_once("baglan.php");

try{
    $ekle = $db->prepare("INSERT  INTO mesaj SET
msjbaslik = ?,
msjicerik = ?
");
    $ekle->execute(array(
       $_SESSION['name'],
$_POST['mesaj']
   ));
    

}
catch (PDOException $e)
{
    echo $e->getMessage();
}
?>