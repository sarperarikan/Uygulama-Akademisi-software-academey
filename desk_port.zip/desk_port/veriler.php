﻿<?php
date_default_timezone_set('Europe/Istanbul');
        require_once("baglan.php");
        try{
function tarihDuzenle($tarih){
return implode('-',array_reverse(explode('-',$tarih)));
}

            $listele = $db->query("SELECT * FROM MESAJ");
            $say = $listele->rowCount();
            if($say)
            {
                foreach($listele  as $cek)
                {
                    print $cek['msjbaslik'] . " ". $cek['msjicerik'] . " " . tarihDuzenle(date('d.m.Y h:i')) . "<br>";
               
				
				
				
				}
            }

        }
        catch(PDOException $h)
        {
            echo $h->getMessage();
        }

        ?>
